package com.example.memo;

public class Data {

    private String title;
    private int image;

    public String gettitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public int getImage() {
        return image;
    }

    public void setImage(int resid) {
        this.image = resid;
    }


}
