package com.example.memo;

public interface ItemTouchHelperListener {
    boolean onItemMove(int from_postion, int to_postion);
    void onItemSwipe(int postion);
}
