package com.example.memo;

//import kotlinx.android.synthetic.main.activity_main.*;

import android.app.Activity;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.util.Log;
import android.view.ContextMenu;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.ItemTouchHelper;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.viewpager.widget.ViewPager;

import com.example.memo.Room.AppDatabase;
import com.example.memo.Room.User;
import com.example.memo.recycle.RecyclerAdapter;

import java.util.Arrays;
import java.util.List;

public class MainActivity extends AppCompatActivity {
    AppDatabase db;
    private static final int SAVE_MEMO = 1;
    boolean editCheck = true;
    boolean fnameCheck = true; // 폴더이름이 같은지 확인
    RecyclerView recyclerView;
    private RecyclerAdapter adapter;
    Button[] nButton;//버튼 생성관련
    LinearLayout layout;
    int count = 0;
    int nButtonId[] = new int[100000]; //버튼 아이디를 따로 저장
    int star[] = new int[100000];
    TextView folder_count; //폴더 개수

    Button btn_allfile, bookmark; // btn_allfile 모든파일, bookmark 즐겨찾기
    ImageButton trash, btn01, btn_edit; //trash 휴지통, btn01 새로만들기, btn_edit 편집

    String value;
    String value_save[] = new String[10000];
    SharedPreferences pref;
    private ItemTouchHelper helper;
    private RecycleAdapter mAdapter;
    LinearLayoutManager linearLayoutManager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        layout = findViewById(R.id.linearLayout3);
        nButton = new Button[10000];
        pref = getSharedPreferences("Save", Context.MODE_PRIVATE);

//-------------------버튼 카운트(갯수) 불러오기-------------------
        count = AppDatabase.getInstance(this).userDao().getAll().size();

        if (count < 0) {
            count = 0;
        } else {
            loadButton();
        }
        for (int i = 0; i < count; i++) {
            SharedPreferences s = getSharedPreferences("star", Context.MODE_PRIVATE);
            star[i] = s.getInt("check_f" + i, 0);
            if (star[i] == 1) {
                Drawable img = getBaseContext().getResources().getDrawable(R.drawable.star);
                img.setBounds(0, 0, 85, 85);
                nButton[i].setCompoundDrawables(img, null, null, null);
                nButton[i].setPadding(70, 0, 0, 0);
            }
        }
        count();//폴더 갯수 표시

//        newFolder = (Button)findViewById(R.id.newFolder);
        //-------------새로만들기 클릭-------------
        btn01 = (ImageButton) findViewById(R.id.newFolder);
        btn01.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                /*while (fnameCheck) {

                }*/
                makebtn();
            }
        });

        //-------------모든파일 클릭-------------
        btn_allfile = (Button) findViewById(R.id.Button1);
        btn_allfile.setOnClickListener(
                new Button.OnClickListener() {
                    public void onClick(View v) {
                        Intent intent = new Intent(getApplicationContext(), allFile.class);
                        Button folder = (Button) findViewById(R.id.Button1);
                        String folder_name = (folder.getText().toString());
                        intent.putExtra("folder_name", folder_name);
                        startActivity(intent);
                    }
                }
        );

        //-------------편집 클릭-------------
        btn_edit = (ImageButton) findViewById(R.id.edit);
        btn_edit.setOnClickListener(
                new View.OnClickListener() {

                    public void onClick(View v) {
                        LayoutInflater inflater = (LayoutInflater) getSystemService(Context.LAYOUT_INFLATER_SERVICE); //화면 전환
                        LinearLayout container;
                        container = findViewById(R.id.linearLayout3);

                        inflater.inflate(R.layout.activity_free_align, container, true);
                        if (editCheck) {
                            trash = (ImageButton) findViewById(R.id.trash);
                            trash.setImageResource(R.drawable.trash_edit);
                            btn_edit.setImageResource(R.drawable.edit_edit);
                            recyclerView.setVisibility(View.GONE);

                            init();
                            getData();
//-------------------------------모두선택 체크박스-------------------------------
                            CheckBox allcheck;

                            allcheck = (CheckBox) container.findViewById(R.id.allcheck);

                            allcheck.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
                                @Override
                                public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                                    if (allcheck.isChecked()) {
                                        mAdapter.selectAll();
                                    } else {
                                        mAdapter.unselectall();
                                    }
                                }
                            });
                            trash.setOnClickListener(new View.OnClickListener() {
                                @Override
                                public void onClick(View v) {
                                    mAdapter.removeItems();
                                }
                            });

                            editCheck = false;
                        } else if (!editCheck) {
                            Intent intent = new Intent(getApplicationContext(), MainActivity.class);

                            trash = (ImageButton) findViewById(R.id.trash);
                            trash.setImageResource(R.drawable.trash);
                            btn_edit.setImageResource(R.drawable.edit);

                            container.removeAllViews();
                            editCheck = true;
//                            loadButton();

                        }
                    }
                }
        );

//-------------------휴지통-------------------
        trash = (ImageButton) findViewById(R.id.trash);
        trash.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (editCheck) {
                    Intent intent = new Intent(getApplicationContext(), trash.class);
                    startActivity(intent);
                    finish();
                } else if (!editCheck) {

                }
            }
        });
//-----------------------즐겨찾기--------------------------
        bookmark = (Button) findViewById(R.id.bookmark);
        Drawable img = getBaseContext().getResources().getDrawable(R.drawable.star);
        img.setBounds(0, 0, 85, 85);
        bookmark.setCompoundDrawables(img, null, null, null);
        bookmark.setPadding(70, 0, 0, 0);
        bookmark.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(), Bookmark.class);

                startActivity(intent);
                finish();
            }
        });
    }

    private void makebtn() {
        final EditText et = new EditText(MainActivity.this);
        AlertDialog.Builder ad = new AlertDialog.Builder(MainActivity.this)
                .setTitle("폴더 생성")
                .setMessage("새로운 폴더 이름을 입력하세요")
                .setView(et);

        ad.setPositiveButton("확인", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                value = et.getText().toString();
                if (!value.equals("")) {
                    String s = et.getText().toString();
                    pushButton();
                    count();
                    fnameCheck = false;
                } else {
                    AlertDialog.Builder noname = new AlertDialog.Builder(MainActivity.this);
                    noname.setTitle("폴더 이름을 입력하세요");
                    //noname.setMessage("제목없는 폴더는 만들수 없습니다");
                    noname.setPositiveButton("확인", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                        }
                    });
                    noname.show();
                }
            }
        });
        ad.setNegativeButton("취소", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                fnameCheck = false;
            }
        });
        ad.show();
    }

    //========================================================함수========================================================

    int check_btn = 0;

    //---------저장된 버튼 불러오기 함수----------
    private void loadButton() {
        //AppDatabase db = Room.databaseBuilder(getApplicationContext(), AppDatabase.class, "memoDatabase").build();
        if (check_btn == 0) {
            for (int i = 0; i < count; i++) {
                nButton[i] = new Button(this);
                value_save[i] = AppDatabase.getInstance(this).userDao().loadFolderTitle(i);
                nButton[i].setText(value_save[i]);
                nButtonId[i] = i;
                nButton[i].setId(nButtonId[i]);
                boolean trashCheck = AppDatabase.getInstance(this).userDao().loadFoldertrash(i); // 휴지통의 파일인지 아닌지 체크
                if(trashCheck == false) {
                    layout.addView(nButton[i], new LinearLayout.LayoutParams(
                            ViewGroup.LayoutParams.MATCH_PARENT,
                            ViewPager.LayoutParams.WRAP_CONTENT));
//                nButtonId[i] = nButton[i].getId();
                    nButton[i].setBackgroundResource(R.drawable.btn_bg);
                    nButton[i].setGravity(Gravity.CENTER_VERTICAL);
                    nButton[i].setTextSize(20);
                    nButton[i].setPadding(120, 0, 0, 0);
                    registerForContextMenu(nButton[i]);//롱클릭했을때 메뉴 뜨는거

                    Drawable img = getBaseContext().getResources().getDrawable(R.drawable.folder);
                    img.setBounds(0, 0, 100, 100);
                    nButton[i].setCompoundDrawables(img, null, null, null);
                    nButton[i].setPadding(70, 0, 0, 0);
                }
                /*value_save[i] = pref.getString("button_name" + i, "");
                nButton[i] = new Button(this);
                nButton[i].setText(value_save[i]);
                nButtonId[i] = pref.getInt("button_id" + i, -1);
                nButton[i].setId(nButtonId[i]);
                layout.addView(nButton[i], new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewPager.LayoutParams.WRAP_CONTENT
                ));

                LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);

//                nButtonId[i] = nButton[i].getId();
                nButton[i].setBackgroundResource(R.drawable.btn_bg);
                nButton[i].setGravity(Gravity.CENTER_VERTICAL);
                nButton[i].setTextSize(20);
                nButton[i].setPadding(120, 0, 0, 0);
                registerForContextMenu(nButton[i]);//롱클릭했을때 메뉴 뜨는거

                Drawable img = getBaseContext().getResources().getDrawable(R.drawable.folder);
                img.setBounds(0, 0, 100, 100);
                nButton[i].setCompoundDrawables(img, null, null, null);
                nButton[i].setPadding(70, 0, 0, 0);
            */}
        } else {
            for (int i = count; i < count; i++) {
                nButton[i] = new Button(this);
                nButton[i].setText(value);
                nButton[i].setId(i + 1);
            }
        }
        Click_btn();
    }

    //-------------버튼생성 함수-------------
    private void pushButton() {
        db = AppDatabase.getInstance(this);
        nButton[count] = new Button(this);
        nButton[count].setText(value);
        nButton[count].setId(count);
        value_save[count] = value;
        nButtonId[count] = count;
        layout.addView(nButton[count], new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewPager.LayoutParams.WRAP_CONTENT
        ));

        nButton[count].setBackgroundResource(R.drawable.btn_bg);
        nButton[count].setGravity(Gravity.CENTER_VERTICAL);
        nButton[count].setTextSize(20);
        nButton[count].setPadding(120, 0, 0, 0);
        registerForContextMenu(nButton[count]);

        Drawable img = getBaseContext().getResources().getDrawable(R.drawable.folder);
        img.setBounds(0, 0, 100, 100);
        nButton[count].setCompoundDrawables(img, null, null, null);
        nButton[count].setPadding(70, 0, 0, 0);

        check_btn = 1;
        loadButton();
        User user = new User(nButtonId[count], value,false,null,null);
        count ++;
        db.userDao().insertAll(user);
    }

    //폴더 클릭시 이동
    private void Click_btn() {
        for (int j = 0; j < count; j++) {
            int temp = j;
            nButton[j].setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    //int resID = getResources().getIdentifier("Button" + i, "id", "com.example.memo");//    int resID = getResources().getIdentifier("com.androidside:id/Button"+i,null,null);
                    Intent intent = new Intent(getApplicationContext(), NewFolder.class);
                    String title = nButton[temp].getText().toString();
                    intent.putExtra("title", title);
                    intent.putExtra("btn_id", nButtonId[temp]);
                    startActivity(intent);
                    finish();
                }
            });
        }
    }

    //------------길게 눌렀을때 메뉴-------------
    String temp; // 폴터 이름

    @Override
    public void onCreateContextMenu(ContextMenu menu, View v, ContextMenu.ContextMenuInfo menuInfo) {
        super.onCreateContextMenu(menu, v, menuInfo);
        for (int i = 0; i < count; i++) {
            if (v == nButton[i]) {
                temp = nButton[i].getText().toString();
                if (star[i] == 0) {
                    menu.add(0, 1, 0, "즐겨찾기");
                } else {
                    menu.add(0, 1, 0, "즐겨찾기 해제");
                }
                menu.add(0, 2, 0, "휴지통");
//                menu.add(0, 3, 0, "상단에 고정");
                menu.add(0, 4, 0, "이름변경");
            }
        }
    }

    /*@Override
    public boolean onContextItemSelected(@NonNull MenuItem item) {
        for (int i = 0; i < count; i++) {

        }
        return super.onContextItemSelected(item);
    }*/

    @Override
    public boolean onContextItemSelected(@NonNull MenuItem item) {
        for (int i = 0; i < count; i++) {
            if (temp == nButton[i].getText().toString()) {
                switch (item.getItemId()) {
                    case 1:
                        if (star[i] == 0) {
                            Drawable img = getBaseContext().getResources().getDrawable(R.drawable.star);
                            img.setBounds(0, 0, 85, 85);
                            nButton[i].setCompoundDrawables(img, null, null, null);
                            nButton[i].setPadding(70, 0, 0, 0);
                            star[i] = 1;
                        } else if (star[i] == 1) {
                            Drawable img = getBaseContext().getResources().getDrawable(R.drawable.folder);
                            img.setBounds(0, 0, 85, 85);
                            nButton[i].setCompoundDrawables(img, null, null, null);
                            nButton[i].setPadding(70, 0, 0, 0);
                            star[i] = 0;
                        }
                        star(i, star[i]);
                        return true;
                    case 2:
//                        User user = new User(nButtonId[i], temp,true,null,null);
                        int trashCount = AppDatabase.getInstance(this).userDao().trashCount();
                        trashCount += 1000;
                        nButton[i].setVisibility(View.GONE);

             /*===================*/           String folderTitleTemp; //여기부터 수정 시작. 맨앞 폴더명을 이 변수에 저장 후 마지막에 nButtonId[i] 넣어준다
                        for(int j = i; j < count; j++){
                            int temp = j + 1;
//                            nButton[i] = nButton[temp];
//                            nButton[i].setId(temp);
                            value_save[j] = value_save[temp];
                            nButtonId[j] = nButtonId[temp];
                            if(!(temp == count)) {
                                AppDatabase.getInstance(this).userDao().updateId(nButtonId[j], value_save[j]);
                            }
                        }

                        AppDatabase.getInstance(this).userDao().updateTrashId(true, trashCount, nButtonId[i]);
                        nButtonId[i] = trashCount;

                        int array [] = new int[count];
                        for(int j = 0; j < count; j++){
                            array[j] = nButtonId[j];
                        }
                        for(int j = 0; j < count; j++){
                            for(int k = j; k < count; k++){
                                if(array[j] > array[k]){
                                    nButtonId[j] = array[k];
                                    nButtonId[k] = array[j];
                                    //
                                }
                            }
                        }
                        check_btn = 1;
                        count();
                        loadButton();
                        return true;
                    case 3:
                        return true;
                    case 4:
                        db = AppDatabase.getInstance(this);
                        AlertDialog.Builder ad = new AlertDialog.Builder(MainActivity.this);
                        ad.setTitle("폴더 이름 변경");
                        ad.setMessage("변경할 폴더 이름을 입력하세요");
                        int temp = i;
                        final EditText et = new EditText(MainActivity.this);
                        et.setText(nButton[i].getText());
                        ad.setView(et);
//------------------------Edit text 열릴때 키보드 올라오는기능---------------------------
                        et.requestFocus();
                        InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
                        imm.toggleSoftInput(InputMethodManager.SHOW_FORCED, InputMethodManager.HIDE_IMPLICIT_ONLY);

                        ad.setPositiveButton("확인", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                value_save[temp] = et.getText().toString();
                                if (!value_save[temp].equals(""))
                                    nButton[temp].setText(value_save[temp]);
                                else {
                                    AlertDialog.Builder noname = new AlertDialog.Builder(MainActivity.this);
                                    noname.setTitle("폴더 이름을 입력하세요");

                                    //noname.setMessage("제목없는 폴더는 만들수 없습니다");
                                    noname.setPositiveButton("확인", new DialogInterface.OnClickListener() {
                                        @Override
                                        public void onClick(DialogInterface dialog, int which) {

                                        }
                                    });
                                    noname.show();
                                }
                                db.userDao().updateFolderTitle(value_save[temp], nButtonId[temp]);
                                InputMethodManager immhide = (InputMethodManager) getSystemService(Activity.INPUT_METHOD_SERVICE);
                                immhide.toggleSoftInput(InputMethodManager.HIDE_IMPLICIT_ONLY, 0);
                            }
                        }).setNegativeButton("취소", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                InputMethodManager immhide = (InputMethodManager) getSystemService(Activity.INPUT_METHOD_SERVICE);
                                immhide.toggleSoftInput(InputMethodManager.HIDE_IMPLICIT_ONLY, 0);
                            }
                        });
                        ad.show();
                        return true;
                }
            }
        }

        return true;
        //return super.onContextItemSelected(item);
    }

    private void star(int i, int check) {
        SharedPreferences pr = getSharedPreferences("star", Context.MODE_PRIVATE);
        SharedPreferences.Editor edit = pr.edit();
        int bm_count = pr.getInt("bm_count_f", 0);

        if (check == 1) {
            edit.putInt("btn_id_f" + i, nButtonId[i]);
            edit.putString("btn_name_f" + i, value_save[i]);
            edit.putInt("check_f" + i, 1);


            SharedPreferences folder_name = getSharedPreferences("folder" + nButtonId[i], Context.MODE_PRIVATE);

            bm_count++;

            edit.putInt("bm_count_f", bm_count);
            //edit.putInt("btn_id",nButtonId[i]);
            edit.commit();
        } else if (check == 0) {
            edit.putInt("btn_id_f" + i, pr.getInt("btn_id_f" + (i + 1), 0));
            edit.putString("btn_name_f" + i, pr.getString("btn_name_f" + (i + 1), ""));
            edit.putInt("check_f" + i, 0);
            bm_count--;
            edit.putInt("bm_count_f", bm_count);
            edit.commit();
        }

    }

    //------------폴더 삭제시 폴더내용 리셋-----------
    private void delete(User user) {
        AppDatabase.getInstance(this).userDao().delete(user);
    }

    private void count() {
        count = AppDatabase.getInstance(this).userDao().getAll().size();
        folder_count = (TextView) findViewById(R.id.folder_count);
        folder_count.setText("폴더: " + (count));
    }

    //-----------앱종료시 저장-------------
    @Override
    protected void onDestroy() {
        Log.i("Destroy", "종료");
        super.onDestroy();
    }

    private void init() {
        RecyclerView recyclerView = findViewById(R.id.recycler);

        linearLayoutManager = new LinearLayoutManager(this);
        recyclerView.setLayoutManager(linearLayoutManager);

        mAdapter = new RecycleAdapter();
        recyclerView.setAdapter(mAdapter);
        helper = new ItemTouchHelper(new ItemTouchHelperCallback(mAdapter));
        helper.attachToRecyclerView(recyclerView);

    }

    private void getData() {
        Intent intent = getIntent();
//        List<String> listTitle = Arrays.asList("국화","사막","수국");
        String btn_name[] = new String[count];
        List<String> listTitle = null;
        for (int i = 0; i < count; i++) {
            btn_name[i] = nButton[i].getText().toString();
//            int resID = getResources().getIdentifier("Button" + i, "id", "com.example.memo");//    int resID = getResources().getIdentifier("com.androidside:id/Button"+i,null,null);
//            btn_name[i] = ((Button) findViewById(resID)).getText().toString();
//            btn_name[i] = intent.getExtras().getString("btn_name" + i);
            listTitle = Arrays.asList(btn_name[i]);
            Data data = new Data();
            data.setTitle(listTitle.get(0));
            mAdapter.addItem(data);
        }
        mAdapter.notifyDataSetChanged();
        /*for(int i = 0;i<listTitle.size();i++){
            Data data = new Data();
            data.setTitle(listTitle.get(i));
            adapter.addItem(data);
        }*/
    }

}
