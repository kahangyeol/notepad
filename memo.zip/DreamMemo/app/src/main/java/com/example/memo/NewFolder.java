package com.example.memo;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.view.ContextMenu;
import android.view.Gravity;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.viewpager.widget.ViewPager;

import com.example.memo.recycle.MemoRecyclerAdapter;

public class NewFolder extends AppCompatActivity {


    RecyclerView recyclerView;
    LinearLayoutManager linearLayoutManager;
    MemoRecyclerAdapter adapter;
    //리사이클러뷰
    ImageButton new_memo;// ID = new_memo
    Button nButton[];
    LinearLayout layout;// ID = memo_list
    //View
    int nButtonId[] = new int[100000];
    int btn_id = 0;
    int [] star = new int [10000];
    int count = 0, check = 0;
    String value,folder_n;
    String [] value_save = new String[100000];
    SharedPreferences pref;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_new_folder);
        TextView title_tv;
        String title;

            new_memo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                move();
            }
        });

        nButton = new Button[10000];
        layout = (LinearLayout) findViewById(R.id.memo_list);
        Intent intent = getIntent();

        btn_id = intent.getExtras().getInt("folderId");

        pref = getSharedPreferences("folder"+btn_id,Context.MODE_PRIVATE);


        count = pref.getInt("count",0);

        int n_check = intent.getExtras().getInt("n_check");
        if(count > 0){
            if(n_check == 1){
                SharedPreferences folder_name = getSharedPreferences("folder"+btn_id, Context.MODE_PRIVATE);
                SharedPreferences.Editor edit = folder_name.edit();
                int mbtn_id_t = intent.getExtras().getInt("mbtn_id")-1;
                edit.putString("button_name"+mbtn_id_t, intent.getExtras().getString("mtitle"));

                edit.commit();
            }
            loadButton();
        }
        for(int i = 0; i < count; i++) {
            SharedPreferences s = getSharedPreferences("star", Context.MODE_PRIVATE);
            star[i] = s.getInt("check"+i,0);
            if (star[i]== 1) {
                Drawable img = getBaseContext().getResources().getDrawable(R.drawable.star);
                img.setBounds(0, 0, 85, 85);
                nButton[i].setCompoundDrawables(img, null, null, null);
                nButton[i].setPadding(70, 0, 0, 0);
            }
        }


        title = intent.getExtras().getString("title");
        check = intent.getExtras().getInt("check");

        folder_n = title;

        if (check == 1){
            value = intent.getExtras().getString("mtitle");
            //count++;
            pushButton();
        }

        title_tv = findViewById(R.id.title);
        if (title.length() >= 5) {
            title=title.substring(0, 4);
            title = title + "...";
        }
        title_tv.setText(title);
        //-----------------뒤로가기(꺽쇠괄호)클릭----------------------
        ImageButton imageButton10 = (ImageButton) findViewById(R.id.imageButton10);
        imageButton10.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
            }
        });
        // ---------------------새로만들기 클릭--------------------------
        new_memo = findViewById(R.id.new_memo);
        new_memo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(), create_memo.class);
                intent.putExtra("folder_name", folder_n);//폴더이름 전송
                intent.putExtra("count",count);
                intent.putExtra("btn_id",btn_id);
                check = 1;
                intent.putExtra("check",check);
                save();
                startActivity(intent);
                finish();
            }
        });
        ImageButton trash;
        trash = (ImageButton) findViewById(R.id.trash);
        trash.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(),trash.class);
                startActivity(intent);
                finish();
            }
        });
    }

    private void move() {
    }

    int check_btn = 0;
    //---------저장된 버튼 불러오기 함수----------
    private void loadButton(){
        if(check_btn == 0) {
            for (int i = 0; i < count; i++) {
                value_save[i] = pref.getString("button_name" + i, "");
                nButton[i] = new Button(this);
                nButton[i].setText(value_save[i]);
                nButton[i].setId(i + 1);
                layout.addView(nButton[i], new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewPager.LayoutParams.WRAP_CONTENT
                ));

                LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);

                nButtonId[i] = nButton[i].getId();
                nButton[i].setBackgroundResource(R.drawable.btn_bg);
                nButton[i].setGravity(Gravity.CENTER_VERTICAL);
                nButton[i].setTextSize(20);
                nButton[i].setPadding(120, 0, 0, 0);
                registerForContextMenu(nButton[i]);

                Drawable img = getBaseContext().getResources().getDrawable(R.drawable.notebook);
                img.setBounds(0, 0, 85, 85);
                nButton[i].setCompoundDrawables(img, null, null, null);
                nButton[i].setPadding(70, 0, 0, 0);
            }
        }else{
            for(int i = count; i < count; i++){
                nButton[i] = new Button(this);
                nButton[i].setText(value);
                nButton[i].setId(i+1);
            }
        }
        Click_btn();
    }

    //-------------버튼생성 함수-------------
    private void pushButton() {
        nButton[count] = new Button(this);
        nButton[count].setText(value);
        nButton[count].setId(count + 1);
        value_save[count] = value;
        nButtonId[count] = nButton[count].getId();
        layout.addView(nButton[count], new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewPager.LayoutParams.WRAP_CONTENT
        ));

        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);

        nButton[count].setBackgroundResource(R.drawable.btn_bg);
        nButton[count].setGravity(Gravity.CENTER_VERTICAL);
        nButton[count].setTextSize(20);
        nButton[count].setPadding(120, 0, 0, 0);
        registerForContextMenu(nButton[count]);

        Drawable img = getBaseContext().getResources().getDrawable(R.drawable.notebook);
        img.setBounds(0, 0, 85, 85);
        nButton[count].setCompoundDrawables(img, null, null, null);
        nButton[count].setPadding(70, 0, 0, 0);

        count++;
        check_btn = 1;
        loadButton();
    }





    //폴더 클릭시 이동
    private void Click_btn(){
        for (int j = 0; j < count; j++) {
            int b_temp = j;
            String ttt = nButton[j].getText().toString();
            nButton[j].setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    //int resID = getResources().getIdentifier("Button" + i, "id", "com.example.memo");//    int resID = getResources().getIdentifier("com.androidside:id/Button"+i,null,null);
                    Intent intent = new Intent(getApplicationContext(), create_memo.class);
                    String title = nButton[b_temp].getText().toString();
                    intent.putExtra("count",count);
                    intent.putExtra("folder_name", folder_n);
                    intent.putExtra("mbtn_id",nButtonId[b_temp]);//클릭한 메모 아이디
                    intent.putExtra("btn_id",btn_id);//폴더 아이디
                    intent.putExtra("mtitle",value_save[b_temp]);//메모제목
                    check = 0;
                    intent.putExtra("check",check);
                    startActivity(intent);
                    finish();
                    save();
                }
            });
        }
    }
    //------------길게 눌렀을때 메뉴-------------
    String temp;
    @Override
    public void onCreateContextMenu(ContextMenu menu, View v, ContextMenu.ContextMenuInfo menuInfo) {
        super.onCreateContextMenu(menu, v, menuInfo);
        for(int i = 0;i<count; i++){
            if(v==nButton[i]){
                temp = nButton[i].getText().toString();
                if(star[i] == 0) {
                    menu.add(0, 1, 0, "즐겨찾기");
                }else{
                    menu.add(0, 1, 0, "즐겨찾기 해제");
                }
                menu.add(0, 2, 0, "휴지통");
                menu.add(0, 3, 0, "상단에 고정");
            }
        }
    }

    @Override
    public boolean onContextItemSelected(@NonNull MenuItem item) {
        for(int i = 0; i <count; i++) {
            nButtonId[i] = nButtonId[i];
            if (temp == nButton[i].getText().toString()) {
                switch (item.getItemId()) {
                    case 1:
                        if(star[i] == 0) {
                            Drawable img = getBaseContext().getResources().getDrawable(R.drawable.star);
                            img.setBounds(0, 0, 85, 85);
                            nButton[i].setCompoundDrawables(img, null, null, null);
                            nButton[i].setPadding(70, 0, 0, 0);
                            star[i] = 1;
                        }else if(star[i] == 1){
                            Drawable img = getBaseContext().getResources().getDrawable(R.drawable.notebook);
                            img.setBounds(0, 0, 85, 85);
                            nButton[i].setCompoundDrawables(img, null, null, null);
                            nButton[i].setPadding(70, 0, 0, 0);
                            star[i] = 0;
                        }
                        star(i, star[i]);
                        return true;
                    case 2:
                        trash(i);
                        count--;
                        delete(i);
                        nButton[i].setVisibility(View.GONE);
                        while(i<count){
                            int temp = i+1;
                            nButton[i] = nButton[temp];
                            nButtonId[temp] = nButtonId[i];
                            nButton[temp].setId(nButtonId[temp]);

                            value_save[i] = value_save[temp];
                            i++;
                        }
                        check_btn = 1;
                        loadButton();
                        return true;
                    case 3:
                        return true;
                }
            }
        }
        return true;
        //return super.onContextItemSelected(item);
    }

    public void delete(int i) {
        Intent intent = getIntent();
        int mbtn_id_reset = btn_id * 100 + nButtonId[i];
        SharedPreferences folder_name = getSharedPreferences("memo" + mbtn_id_reset, Context.MODE_PRIVATE);
        SharedPreferences.Editor edit = folder_name.edit();
        SharedPreferences pp;
        edit.putInt("count", 0);
        edit.putString("content", "");
        edit.putString(value_save[i], "");

        for (i = i; i < count; i++) {
            mbtn_id_reset = btn_id * 100 + nButtonId[i];
            folder_name = getSharedPreferences("memo" + mbtn_id_reset, Context.MODE_PRIVATE);
            edit = folder_name.edit();
            int mbtn_id_reset_h = mbtn_id_reset+1;
            pp = getSharedPreferences("memo" + mbtn_id_reset_h, Context.MODE_PRIVATE);
            String change = pp.getString("content", "");
            edit.putString("content", change);
            edit.commit();
        }
    }

    private void trash(int i){
        int mbtn_id_reset = btn_id * 100 + nButtonId[i];
        SharedPreferences trash = getSharedPreferences("trash",Context.MODE_PRIVATE);
        SharedPreferences.Editor edit = trash.edit();
        int trash_count = trash.getInt("trash_count",-1);

        edit.putInt("btn_id",btn_id);//폴더 아이디
        //edit.putString("folder_name"+btn_id,folder_n );//폴더이름
//        edit.putString("title",folder_n);
        edit.putString("button_name"+trash_count, value_save[i]);//메모 이름
        edit.putInt("mbtn_id"+trash_count,mbtn_id_reset);//메모 아이디
        trash_count++;
        edit.putInt("trash_count",trash_count);//휴지통 카운트

        edit.commit();
    }
    private void star(int i, int check){
        SharedPreferences star = getSharedPreferences("star", Context.MODE_PRIVATE);
        SharedPreferences.Editor edit = star.edit();
        int bm_count = star.getInt("bm_count", 0);
        if(check == 1) {
            int mbtn_id = btn_id * 100 + nButtonId[i];
            edit.putString("btn_name" + i, value_save[i]);//메모 이름
            edit.putInt("mbtn_id" + i, mbtn_id);//메모 아이디
            edit.putInt("check"+i,1);
            bm_count++;
            edit.putInt("bm_count", bm_count);//즐겨찾기 메모 카운트

            edit.commit();
        } else if (check == 0) {
            edit.putString("btn_name"+i,star.getString("btn_name"+(i+1),""));
            edit.putInt("mbtn_id"+i,star.getInt("mbtn_id"+(i+1),0 ));
            edit.putInt("check"+i,0);
            bm_count -- ;
            edit.putInt("bm_count",bm_count);
            edit.commit();
        }
    }
    @Override
    public void onBackPressed() {
        super.onBackPressed();
        Intent intent1 = getIntent();
        if(intent1.getExtras().getInt("bm_check",0)==1){
            Intent intent = new Intent(getApplicationContext(),Bookmark.class);
            startActivity(intent);
        }else{
            Intent intent = new Intent(getApplicationContext(),MainActivity.class);
            startActivity(intent);
        }

        save();
    }

    public void save(){
        SharedPreferences folder_name = getSharedPreferences("folder"+btn_id, Context.MODE_PRIVATE);
        SharedPreferences.Editor edit = folder_name.edit();

        edit.putInt("count",count);
        edit.putString("title",folder_n);
        for (int i = 0; i < count; i++) {
            edit.putInt("mbtn_id"+i,nButtonId[i]);
            edit.putString("button_name"+i, value_save[i]);
//            edit.putInt("nButtonId"+i, nButtonId[i]);
        }


        SharedPreferences folder_name1 = getSharedPreferences("folder_t"+btn_id, Context.MODE_PRIVATE);
        SharedPreferences.Editor edit1 = folder_name1.edit();

        edit1.putInt("count",count);
        edit1.putString("title",folder_n);
        for (int i = 0; i < count; i++) {
            edit1.putString("button_name"+i, value_save[i]);
//            edit.putInt("nButtonId"+i, nButtonId[i]);
        }
        edit.commit();
        edit1.commit();
    }
}