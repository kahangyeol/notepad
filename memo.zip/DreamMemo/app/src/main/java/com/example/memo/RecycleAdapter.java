package com.example.memo;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class RecycleAdapter extends RecyclerView.Adapter<RecycleAdapter.ItemViewHolder> implements ItemTouchHelperListener{
    private ArrayList<Data> listData = new ArrayList<>();
    private Map<Data,Boolean> mCheckedMap = new HashMap<>();
    private List<Data> mCheckedDataList = new ArrayList<>();
    private int[]a=new int[100000];
    int i=0;
    public void removeItems(){
        listData.removeAll(mCheckedDataList);
        notifyDataSetChanged();
    }

    public void star(){

    }

    boolean isSelectedAll = false;
    public void selectAll(){
        isSelectedAll=true;
        notifyDataSetChanged();
    }
    public void unselectall(){
        isSelectedAll=false;
        notifyDataSetChanged();
    }

    @NonNull
    @Override
    public ItemViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.free_align_item,parent, false);

        final ItemViewHolder ItemViewHolder= new ItemViewHolder(view);

        ItemViewHolder.checkBox.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                Data data = listData.get(ItemViewHolder.getAdapterPosition());
                mCheckedMap.put(data, isChecked);

                if(isChecked){

                    mCheckedDataList.add(data);

                }else{
                    mCheckedDataList.remove(data);
                }
            }
        });

//        return new ItemViewHolder(view);
        return ItemViewHolder;
    }



    @Override
    public void onBindViewHolder(@NonNull ItemViewHolder holder, int position) {

            Data data = listData.get(position);

            //holder.list_image.setImageResource(R.mipmap.ic_launcher);
            holder.list_name.setText(data.gettitle());
            // holder.list_name.setText();
            /*holder.onBind(listData.get(position));*/
            if(!isSelectedAll){
                holder.checkBox.setChecked(false);
            }else{
                holder.checkBox.setChecked(true);
            }
            boolean isChecked = mCheckedMap.get(data) ==  null
                    ? false
                    : mCheckedMap.get(data);
            /*if(isChecked){
                a[i] = position;
                i++;
            }*/
            holder.checkBox.setChecked(isChecked);

        /*if(mCheckedMap.get(data)){
            holder.list_name.setChecked(true);
        }else{
            holder.list_name.setChecked(false);
        }
        holder.list_name.setChecked(isChecked);*/

         holder.onBind(listData.get(position));
    }

    @Override
    public int getItemCount() {
        return listData.size();
    }
    void addItem(Data data){
        listData.add(data);
    }

    public void setAllChecked(final boolean ischeked) {

    }

    @Override
    public boolean onItemMove(int from_position, int to_position) {
        //이동할 객체 저장
        Data person = listData.get(from_position);
        //이동할 객체 삭제
        listData.remove(from_position);
        //이동하고 싶은 position에 추가
        listData.add(to_position,person);

        //Adapter에 데이터 이동알림
        notifyItemMoved(from_position,to_position);
        return true;
    }

    @Override
    public void onItemSwipe(int position) {
        listData.remove(position);
        notifyItemRemoved(position);
    }

    // item 설정(?)
    class ItemViewHolder extends RecyclerView.ViewHolder {

        CheckBox checkBox;
        TextView list_name;
        ImageView list_image;


        public ItemViewHolder(View itemView) {
            super(itemView);
            list_name = itemView.findViewById(R.id.textView);
            list_image = itemView.findViewById(R.id.imageView);
            checkBox = itemView.findViewById(R.id.checkbox);
        }

        public int onBind(Data person) {
            list_name.setText(person.gettitle());
            list_image.setImageResource(person.getImage());
                return 0;
        }
    }
}

/*
    @Override
    public boolean onItemMove(int from_postion, int to_position){
        Data data = listData.get(from_postion);
        listData.remove(from_postion);
        listData.add(to_position,data);
        notifyItemMoved(from_postion,to_position);
        return true;
    }



    class ItemViewHolder extends RecyclerView.ViewHolder{

        private TextView textView;

        public ItemViewHolder(@NonNull View itemView) {
            super(itemView);
//            textView = (TextView) itemView.findViewById(R.id.title);
            textView = itemView.findViewById(R.id.title);
        }
        void onBind(Data data){
            textView.setText(data.gettitle());
        }

    }

}
*/
