package com.example.memo.Room;

import androidx.room.ColumnInfo;
import androidx.room.Entity;
import androidx.room.PrimaryKey;

@Entity(tableName = "memoTable")
public class User {
    @PrimaryKey(autoGenerate = false)
    public int id;

    @ColumnInfo(name = "folderTitle")
    public String folderTitle;

    @ColumnInfo(name = "memoTitle")
    public String memoTitle;

    @ColumnInfo(name = "content")
    public String content;

    @ColumnInfo(name = "trash")
    public boolean trash;

    public User (int id, String folderTitle, boolean trash,String memoTitle, String content){
        this.id = id;
        this.folderTitle = folderTitle;
        this.trash = trash;
        this.memoTitle = memoTitle;
        this.content = content;
    }
}
