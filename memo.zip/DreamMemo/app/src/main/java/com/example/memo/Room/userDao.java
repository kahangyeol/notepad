package com.example.memo.Room;

import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.Query;
import androidx.room.Update;

import java.util.List;

@Dao
public interface userDao {
    @Query("SELECT * FROM memoTable WHERE trash = 0")
    List<User> getAll();

    @Query("SELECT content FROM memoTable WHERE folderTitle LIKE :folderTitle AND memoTitle LIKE :memoTitle LIMIT 1 ")
    User findcontent(String folderTitle, String memoTitle);

    @Query("SELECT folderTitle FROM memoTable WHERE id = :id")
    String loadFolderTitle(int id);

    @Query("SELECT trash FROM memoTable WHERE id = :id")
    boolean loadFoldertrash(int id);

    @Query("UPDATE memoTable SET id = :id WHERE folderTitle = :folderTitle")
    void updateId(int id, String folderTitle);

    @Query("UPDATE memoTable SET folderTitle = :folderTitle WHERE id = :id")
    void updateFolderTitle(String folderTitle,int id);

    @Query("SELECT COUNT(id) FROM memoTable WHERE id >= 1000")
    int trashCount();

    @Query("UPDATE memoTable SET trash = :trash, id = :trashId WHERE id = :id")
    void updateTrashId (boolean trash, int trashId, int id);

    @Update
    void update(User user);

    @Insert
    void insertAll(User...user);

    @Delete
    void delete(User user);
}
