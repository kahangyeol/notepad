package com.example.memo;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.LinearLayout;

import androidx.appcompat.app.AppCompatActivity;
import androidx.viewpager.widget.ViewPager;

public class allFile extends AppCompatActivity {
    int count;
    int mbtn_id [] = new int[100000];
    int mbtn_id_t [] = new int[100000];
    int btn_id [] = new int[100000];
    int nButtonId [] = new int[100000];
    Button nButton[] = new Button[100000];
    LinearLayout layout;
    String folder_t,value;
    String [] value_save = new String[100000];
    String [] folder_n = new String[100000];
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_all_file);
        layout = (LinearLayout) findViewById(R.id.linearLayout3);
        SharedPreferences pref_f = getSharedPreferences("Save",MODE_PRIVATE);
        int count_f = pref_f.getInt("count",0);
        for(int i = 0; i < count_f; i++){
            btn_id[i] = pref_f.getInt("button_id"+i,0);
            SharedPreferences pref_m = getSharedPreferences("folder"+btn_id[i], Context.MODE_PRIVATE);
            int count_m = pref_m.getInt("count",0);
            for(int j = 0; j<count_m; j++){
                value_save[count] = pref_m.getString("button_name" + j, "");
                mbtn_id[count] = pref_m.getInt("mbtn_id"+j,0);
                mbtn_id_t[count] = btn_id[i] * 100 + mbtn_id[count];
                count++;
            }
            folder_n[i] = pref_f.getString("button_name"+i,"");
        }
        loadButton();

//-----------------뒤로가기(꺽쇠괄호)클릭----------------------
        ImageButton imageButton10 = (ImageButton) findViewById(R.id.imageButton10);
        imageButton10.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
            }
        });
/*


        Button btn_1 = (Button) findViewById(R.id.Button1);
        TextView textView = (TextView)findViewById(R.id.textView3) ;

        Intent intent = getIntent();
        String folder_name = intent.getExtras().getString("folder_name");//폴더 이름 받아옴
        folder_t = folder_name;//임시변수에 폴더 이름을 저장

        if (folder_name.length() >= 5) {//폴더이름이 5글자 이상일때 4글자부터 자르고 ... 으로 변경
            folder_name=folder_name.substring(0, 4);
            folder_name = folder_name + "...";
        }
        textView.setText(folder_name);

        btn_1.setOnClickListener(new View.OnClickListener() { // 메모 클릭했을때
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(),memo1.class);
                Button btn_1 = (Button) findViewById(R.id.Button1);
                String file_name = btn_1.getText().toString();//파일이름을 String 변수에 저장
                intent.putExtra("file_name",file_name);//파일이름 전송
                intent.putExtra("folder_name",folder_t);//폴더이름 전송
                startActivity(intent);
            }
        });

        Button newFile = (Button) findViewById(R.id.newFile);
        newFile.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(), create_memo.class);
                intent.putExtra("folder_name",folder_t);//폴더이름 전송
                startActivity(intent);
            }
        });*/
    }
    int check_btn = 0;
    private void loadButton(){
        if(check_btn == 0) {
            for (int i = 0; i < count; i++) {
                nButton[i] = new Button(this);
                nButton[i].setText(value_save[i]);
                nButton[i].setId(mbtn_id[i]);
                layout.addView(nButton[i], new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewPager.LayoutParams.WRAP_CONTENT
                ));

                LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);

                nButtonId[i] = nButton[i].getId();
                nButton[i].setBackgroundResource(R.drawable.btn_bg);
                nButton[i].setGravity(Gravity.CENTER_VERTICAL);
                nButton[i].setTextSize(20);
                nButton[i].setPadding(120, 0, 0, 0);
                registerForContextMenu(nButton[i]);
            }
        }else{
            for(int i = count; i < count; i++){
                nButton[i] = new Button(this);
                nButton[i].setText(value);
                nButton[i].setId(i+1);
            }
        }
        Click_btn();
    }
    int check = 0;
    private void Click_btn(){
        for (int j = 0; j < count; j++) {
            int b_temp = j;
            String ttt = nButton[j].getText().toString();
            nButton[j].setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    //int resID = getResources().getIdentifier("Button" + i, "id", "com.example.memo");//    int resID = getResources().getIdentifier("com.androidside:id/Button"+i,null,null);
                    Intent intent = new Intent(getApplicationContext(), create_memo.class);
                    int ctemp = mbtn_id_t[b_temp]/100;

                    String title = nButton[b_temp].getText().toString();
                    intent.putExtra("count",count);
                    intent.putExtra("folder_name", folder_n[ctemp-1]);
                    intent.putExtra("mbtn_id",nButtonId[b_temp]);//클릭한 메모 아이디
                    intent.putExtra("btn_id",ctemp);//폴더 아이디
                    intent.putExtra("mtitle",value_save[b_temp]);//메모제목
                    intent.putExtra("check",check);
                    int back = 1;
                    intent.putExtra("back",back);

                    startActivity(intent);
                    finish();
                }
            });
        }
    }
}