package com.example.memo;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class create_memo extends AppCompatActivity {
    TextView mFolder_name;
    String mtitle, content;
    int mbtn_id_t=0;
    int count = 0;
    int btn_id = 0, check = 1, mbtn_id = 0, mb_check;
    EditText des;
    EditText title;
    String folder_nt;
    String value_save[] = new String[10000];
    SharedPreferences pref;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_create_memo);

        //-----------------뒤로가기(꺽쇠괄호)클릭----------------------
        ImageButton imageButton10 = (ImageButton) findViewById(R.id.imageButton10);
        imageButton10.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
            }
        });
        Intent intent = getIntent();
        check = intent.getExtras().getInt("check");

        String folder_name = intent.getExtras().getString("folder_name");//폴더이름 가져오기

        folder_nt = folder_name;
        if (folder_name.length() >= 5) {
            folder_name = folder_name.substring(0, 4);
            folder_name = folder_name + "...";
        }

        if (check == 0) {


            mbtn_id = intent.getExtras().getInt("mbtn_id");//클릭한 메모의 아이디
            mbtn_id_t = mbtn_id;//메모의 아이디를 받아옴
            count = intent.getExtras().getInt("count");
            btn_id = intent.getExtras().getInt("btn_id");//폴더의 아이디
            mbtn_id = btn_id*100+mbtn_id;//아이디가 1인 폴더의 아이디가 1인 메모의 아이디 101
            mtitle = intent.getExtras().getString("mtitle");//메모제목 가져오기
            pref = getSharedPreferences("memo"+mbtn_id,Context.MODE_PRIVATE);
            content = pref.getString("content","");//메모내용 불러오기



            EditText content_et = (EditText) findViewById(R.id.content);
            EditText title_et = (EditText) findViewById(R.id.title);

            content_et.setText(content);
            title_et.setText(mtitle);

            Button succes = (Button) findViewById(R.id.succes);
            succes.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    EditText content_et = (EditText) findViewById(R.id.content);
                    EditText title_et = (EditText) findViewById(R.id.title);

                    mtitle = title_et.getText().toString();
                    content = content_et.getText().toString();

                    if(mtitle.equals("")){
                        mtitle = "제목없음";
                    }
                    content_et.setText(content);
                    title_et.setText(mtitle);

                    toast();
                    save(title_et,content_et);

                    /*Intent intent = new Intent(getApplicationContext(), newFolder.class);

                    intent.putExtra("mbtn_id",mbtn_id_t);
                    intent.putExtra("btn_id", btn_id);
                    intent.putExtra("count", count);
                    intent.putExtra("mtitle", mtitle);
                    intent.putExtra("title", folder_nt);
                    intent.putExtra("check", check);
                    intent.putExtra("mbtn_id_reset",mbtn_id);
                    intent.putExtra("n_check",n_check);
                    startActivity(intent);
                    finish();*/
                }
            });
        }else if(check == 1){
            btn_id = intent.getExtras().getInt("btn_id");
            count = intent.getExtras().getInt("count");
            count++;
            mbtn_id = btn_id*100+count;

            Button succes = (Button) findViewById(R.id.succes);
            succes.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    EditText title = (EditText) findViewById(R.id.title);
                    EditText content = (EditText) findViewById(R.id.content);

                    mtitle = title.getText().toString();
                    if(mtitle.equals(""))
                        mtitle = "제목없음";

                    save(title, content);

                    Intent intent = new Intent(getApplicationContext(), NewFolder.class);
                    intent.putExtra("count", count);
                    intent.putExtra("title",folder_nt);
                    intent.putExtra("mtitle",mtitle);
                    intent.putExtra("btn_id",btn_id);
                    intent.putExtra("check", check);
                    intent.putExtra("mbtn_id_reset",mbtn_id);

                    startActivity(intent);
                    finish();
                }
            });
        }
    }

    private void toast(){
        Toast toast = Toast.makeText(this.getApplicationContext(),"저장되었습니다",Toast.LENGTH_SHORT);
        toast.show();
    }

    @Override
    public void onBackPressed() {
        Intent back_i = getIntent();
        int back = back_i.getExtras().getInt("back",0);//즐겨찾기에서 넘어온건지 체크
        if(back == 1){
            Intent intent = new Intent(getApplicationContext(),allFile.class);
            autoSave(intent);
        }else {
            int n_check = 1;
            Intent intent = new Intent(getApplicationContext(), NewFolder.class);

            intent.putExtra("mbtn_id",mbtn_id_t);
            intent.putExtra("btn_id", btn_id);
            intent.putExtra("count", count);
            intent.putExtra("mtitle", mtitle);
            intent.putExtra("title", folder_nt);
            intent.putExtra("check", check);
            intent.putExtra("mbtn_id_reset",mbtn_id);
            intent.putExtra("n_check",n_check);
            startActivity(intent);
            finish();

            /*Intent intent = new Intent(getApplicationContext(), newFolder.class);
            autoSave(intent);*/
        }/*Intent intent1 = getIntent();
            if (intent1.getExtras().getInt("bm_ckeck", 0) == 1) {
                Intent intent2 = new Intent(getApplicationContext(), Bookmark.class);
                startActivity(intent2);
            } else if (intent1.getExtras().getInt("bm_check") == 0) {

                EditText title_et = (EditText) findViewById(R.id.title);
                mtitle = title_et.getText().toString();
                if (mtitle.equals(""))
                    mtitle = "제목없음";
                intent.putExtra("mtitle", mtitle);
                intent.putExtra("btn_id", btn_id);
                intent.putExtra("count", count);
                intent.putExtra("title", folder_nt);
                intent.putExtra("check", check);
                startActivity(intent);
                finish();
            }
            super.onBackPressed();
        }*/
    }
    private void autoSave(Intent intent){
        EditText title_et = (EditText) findViewById(R.id.title);
        mtitle = title_et.getText().toString();
        if (mtitle.equals(""))
            mtitle = "제목없음";
        intent.putExtra("mtitle", mtitle);
        intent.putExtra("btn_id", btn_id);
        intent.putExtra("count", count);
        intent.putExtra("title", folder_nt);
        intent.putExtra("check", check);
        startActivity(intent);
        finish();
    }
    private void save(TextView title_et, TextView content_et){
        String mtitle = title_et.getText().toString();
        String mcontent = content_et.getText().toString();

        SharedPreferences sharedPreferences = getSharedPreferences("memo" + mbtn_id, Context.MODE_PRIVATE);
        SharedPreferences.Editor edit = sharedPreferences.edit();

//        edit.putInt("count", count);
        edit.putString("content", mcontent);
        edit.putString(mtitle, mtitle);

        edit.commit();
    }
}
