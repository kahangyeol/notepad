package com.example.memo.recycle;

public class MemoRecyclerAdapter{
/*

    private ArrayList<User> userData = new ArrayList<>();

    @NonNull
    @Override
    public RecyclerAdapter.MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        return null;
    }

    @Override
    public void onBindViewHolder(@NonNull RecyclerAdapter.MyViewHolder holder, int position) {
        holder.onBind(userData.get(position), position);
    }

    @Override
    public int getItemCount() {
        return userData.size();
    }
        userData.add(user);
    notifyDataSetChanged();
}

    public void addItems(ArrayList<User> users){
        userData = users;
        notifyDataSetChanged();
    }
public class MyViewHolder extends RecyclerView.ViewHolder{
    private TextView id;
    private TextView title;
    private TextView des;
    private ImageView memoImg;


    public MyViewHolder(@NonNull View itemView) {
        super(itemView);

        id = itemView.findViewById(R.id.memoID);
        title = itemView.findViewById(R.id.memoTitle);
        memoImg = itemView.findViewById(R.id.memoImg);

    }
    public void Bind(User user, int postion){
        String s = ""+(postion);
        id.setText(s);
        title.setText(user.getF_name());

    }
}
*/
}