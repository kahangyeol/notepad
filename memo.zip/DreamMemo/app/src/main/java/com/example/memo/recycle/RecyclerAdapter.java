package com.example.memo.recycle;

public class RecyclerAdapter{/*

    AppDatabase db;
    Context mContext;
    private ArrayList<User> userData = new ArrayList<>();

    private int mPostion = RecyclerView.NO_POSITION;

    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.folderrecycler_itemview, parent, false);
        AdapterView.OnItemLongClickListener listener = new AdapterView.OnItemLongClickListener() {
            @Override
            public boolean onItemLongClick(AdapterView<?> parent, View view, int position, long id) {

                return false;
            }
        };
        return new MyViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull MyViewHolder holder, int position) {
        holder.onBind(userData.get(position), position);
    }

    @Override
    public int getItemCount() {
        return userData.size();
    }

        public void addItem(User user) {
            userData.add(user);
            notifyDataSetChanged();
        }

        public void addItems(ArrayList<User> users) {
            userData = users;
            notifyDataSetChanged();
        }


    public class MyViewHolder extends RecyclerView.ViewHolder implements View.OnCreateContextMenuListener {

        private TextView id;
        private TextView f_name;
        private TextView memo;
        private ImageView bookmark;

        public MyViewHolder(@NonNull View itemView) {
            super(itemView);

            itemView.setOnCreateContextMenuListener(this);
//            key = itemView.findViewById(R.id.key);
            f_name = itemView.findViewById(R.id.memoTextView1);
//            description = itemView.findViewById(R.id.memoTextView2);
            bookmark = itemView.findViewById(R.id.imageView);

        }
        public void del(User user, int postion){
            userData.remove(user);
            AppDatabase.getInstance(itemView.getContext()).userDao().delete(user);

            notifyDataSetChanged();
        }

        public void onBind(User user, int position) {
            String s = "" + (position + 1);
//            key.setText(s); //id
            f_name.setText(user.getF_name()); //title
            bookmark.getContext().getResources().getDrawable(R.drawable.star);
//            description.setText(user.getDes()); //des

            *//*itemView.setOnLongClickListener(v -> {
                userData.remove(user);
                AppDatabase.getInstance(itemView.getContext()).userDao().delete(user);

                notifyDataSetChanged();
                return false;
            });*//*

            itemView.setOnClickListener(v -> {

                Intent intent = new Intent(itemView.getContext(), NewFolder.class);
                intent.putExtra("title", user.getF_name());
                intent.putExtra("folderId", user.getId());
                itemView.getContext().startActivity(intent);

            });

            itemView.setOnCreateContextMenuListener(this);

        }

        @Override
        public void onCreateContextMenu(ContextMenu menu, View v, ContextMenu.ContextMenuInfo menuInfo) {
//            ((Activity) v.getContext()).getMenuInflater().inflate(R.menu.list_menu,menu);
            MenuItem star = menu.add(Menu.NONE, 1001, 1, "즐겨찾기");
            MenuItem delete = menu.add(Menu.NONE, 1002, 2, "휴지통");
//            MenuItem pix = menu.add(Menu.NONE, 1003, 3, "상단에 고정");
            MenuItem update = menu.add(Menu.NONE, 1004, 4, "이름변경");
            star.setOnMenuItemClickListener(onEditMenu);
            delete.setOnMenuItemClickListener(onEditMenu);
            //pix.setOnMenuItemClickListener(onEditMenu);
            update.setOnMenuItemClickListener(onEditMenu);
        }

        private final MenuItem.OnMenuItemClickListener onEditMenu = new MenuItem.OnMenuItemClickListener() {
            @Override
            public boolean onMenuItemClick(MenuItem item) {

                switch (item.getItemId()) {
                    case 1001:

                        break;
                    case 1002:
                        del(userData.get(getAdapterPosition()),getPostion());

                        notifyDataSetChanged();
                        *//*String folderName = userData.get(getAdapterPosition()).getTitle().toString();
                        userData.get(getAdapterPosition());
                        User user = new User(userData.get(getAdapterPosition()).getTitle(),userData.get(getAdapterPosition()).getDes());

                        userData.remove(getAdapterPosition());
                        AppDatabase.getInstance(itemView.getContext()).userDao().delete(user);
                        notifyDataSetChanged();*//*

                        break;
                    case 1003:
                        break;
                    case 1004:
                        AlertDialog.Builder builder = new AlertDialog.Builder(mContext);
//                        View view = LayoutInflater.from(mContext).inflate(R.layout, null, false);
                        builder.setTitle("폴더 이름 변경");
                        builder.setMessage("변경할 폴더 이름을 입력하세요");
                        final EditText et = new EditText(mContext);
                        et.setText(userData.get(getAdapterPosition()).getF_name());
                        builder.setView(et);
                        builder.setPositiveButton("확인", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                String editButtonName = et.getText().toString();
                                User folderName = new User(editButtonName, null);
                                userData.set(getAdapterPosition(), folderName);
                                //변경 이름 저장
                                db = AppDatabase.getInstance(mContext);
                                db.userDao().update(folderName);

                                notifyItemChanged(getAdapterPosition());
                                dialog.dismiss();
                            }
                        }).setNegativeButton("취소", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {

                            }
                        });
                        builder.show();
                        break;
                }
                return false;
            }

        };
    }

    public int getPostion() {
        return mPostion;

    }
    public void img() {


    }*/
}


