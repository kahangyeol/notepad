package com.example.memo;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.viewpager.widget.ViewPager;

import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.view.ContextMenu;
import android.view.Gravity;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

public class trash extends AppCompatActivity {
    int btn_id_f = 0;
    Button nButton[];
    Button nButton_f[];
    TextView folder_count, memo_count;
    String [] value_save = new String[100000];
    String [] value_save_f = new String[100000];
    int count,mbtn_id,count_f;
    int nButtonId[] = new int[100000];
    int nButtonId_f[] = new int[100000];
    LinearLayout layout;
    SharedPreferences pref;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_trash);

        nButton = new Button[10000];
        nButton_f = new Button[10000];

        pref = getSharedPreferences("trash", Context.MODE_PRIVATE);

        count_f = pref.getInt("trash_count_f",-1);
        count = pref.getInt("trash_count",-1);
        //mbtn_id = pref.getInt("mbtn_id",-1);
        layout = (LinearLayout) findViewById(R.id.linearLayout3);

        loadButton();
        count();
        Button rollback = (Button)findViewById(R.id.rollback);
        rollback.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(count_f > 0 || count > 0) {
                    for (int i = 0; i < count; i++) {
                        Rollback(i);
                    }
                    for (int i = 0; i <= count_f; i++) {
                        Rollback_f(i);
                    }
                }else{
                    Toast.makeText(trash.this, "복원할 폴더 또는 메모가 없습니다.", Toast.LENGTH_SHORT).show();
                }
            }
        });
//-----------------뒤로가기(꺽쇠괄호)클릭----------------------
        ImageButton imageButton10 = (ImageButton) findViewById(R.id.imageButton10);
        imageButton10.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
            }
        });
//-------------비우기----------------------------
        Button clear = (Button)findViewById(R.id.clear);
        clear.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                SharedPreferences.Editor edit = pref.edit();
                for(int i = 0; i <count; i++)
                    nButton[i].setVisibility(View.GONE);
                for(int i = 0; i <count_f; i++)
                    nButton_f[i].setVisibility(View.GONE);
                count = 0;
                count_f=0;
                edit.putInt("count",count);
                edit.putInt("count_f ",count_f);
                edit.commit();
                count();
                save();
                /*AlertDialog.Builder ad = new AlertDialog.Builder(trash.this);
                ad.setTitle("모두 삭제 하시겠습니까?");
                ad.setPositiveButton("확인", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        SharedPreferences.Editor edit = pref.edit();
                        for(int i = 0; i <count; i++)
                            nButton[i].setVisibility(View.GONE);
                        for(int i = 0; i <count_f; i++)
                            nButton_f[i].setVisibility(View.GONE);
                        count = 0;
                        count_f=0;
                        edit.putInt("count",count);
                        edit.putInt("count_f ",count_f);
                        edit.commit();
                        save();
                    }
                });
                ad.setPositiveButton("취소", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {

                    }
                });*/
            }
        });


    }
    //---------메모와 폴더 개수----------
    private void count(){
        folder_count = (TextView) findViewById(R.id.folder);
        memo_count = (TextView) findViewById(R.id.memo);

        String memo_s = "메모: "+count+"개";
        String folder_s = "폴더: "+count_f+"개";

        folder_count.setText(folder_s);
        memo_count.setText(memo_s);
    }

    //---------저장된 버튼 불러오기 함수----------
    private void loadButton() {
        layout = (LinearLayout) findViewById(R.id.linearLayout4);
        for (int i = 0; i < count; i++) {
            int temp = i+1;
            mbtn_id = pref.getInt("mbtn_id"+i,-1);
            value_save[i] = pref.getString("button_name" + i, "");
            nButton[i] = new Button(this);
            nButton[i].setText(value_save[i]);
            nButton[i].setId(mbtn_id);
            layout.addView(nButton[i], new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewPager.LayoutParams.WRAP_CONTENT
            ));

            LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);

            nButtonId[i] = nButton[i].getId();
            nButton[i].setBackgroundResource(R.drawable.btn_bg);
            nButton[i].setGravity(Gravity.CENTER_VERTICAL);
            nButton[i].setTextSize(20);
            nButton[i].setPadding(120, 0, 0, 0);
            registerForContextMenu(nButton[i]);

            Drawable img = getBaseContext().getResources().getDrawable(R.drawable.notebook);
            img.setBounds(0, 0, 85, 85);
            nButton[i].setCompoundDrawables(img, null, null, null);
            nButton[i].setPadding(70, 0, 0, 0);
        }
        Click_btn();
        for (int i = 0; i < count_f; i++) {
            layout = (LinearLayout) findViewById(R.id.linearLayout3);
            btn_id_f = pref.getInt("btn_id"+i,-1);
            value_save_f[i] = pref.getString("button_name_f" + i, "");
            nButton_f[i] = new Button(this);
            nButton_f[i].setText(value_save_f[i]);
            nButton_f[i].setId(btn_id_f);
            layout.addView(nButton_f[i], new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewPager.LayoutParams.WRAP_CONTENT
            ));

            LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);

            nButtonId_f[i] = nButton_f[i].getId();
            nButton_f[i].setBackgroundResource(R.drawable.btn_bg);
            nButton_f[i].setGravity(Gravity.CENTER_VERTICAL);
            nButton_f[i].setTextSize(20);
            nButton_f[i].setPadding(120, 0, 0, 0);
            registerForContextMenu(nButton_f[i]);

            Drawable img = getBaseContext().getResources().getDrawable(R.drawable.folder);
            img.setBounds(0, 0, 85, 85);
            nButton_f[i].setCompoundDrawables(img, null, null, null);
            nButton_f[i].setPadding(70, 0, 0, 0);
        }
        Click_btn_f();
    }


    private void Click_btn(){
        for (int j = 0; j < count; j++) {
            int b_temp = j;
            String ttt = nButton[j].getText().toString();
            nButton[j].setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    //int resID = getResources().getIdentifier("Button" + i, "id", "com.example.memo");//    int resID = getResources().getIdentifier("com.androidside:id/Button"+i,null,null);
                    Intent intent = new Intent(getApplicationContext(), trash_memo.class);
                    int btn_id = nButtonId[b_temp]/100;
                    SharedPreferences pr = getSharedPreferences("folder"+btn_id, Context.MODE_PRIVATE);
                    String folder_n = pr.getString("title","");

                    String title = nButton[b_temp].getText().toString();
                   // intent.putExtra("count",count);
                    intent.putExtra("folder_name", folder_n);
                    intent.putExtra("mbtn_id",nButtonId[b_temp]);//클릭한 메모 아이디
                    intent.putExtra("btn_id",btn_id);//폴더 아이디
                    intent.putExtra("mtitle",value_save[b_temp]);//메모제목
                    int check = 0;
                    intent.putExtra("check",check);
                    startActivity(intent);
                    finish();
                    save();
                }
            });
        }
    }
    private void Click_btn_f() {
        for (int j = 0; j < count_f; j++) {
            int b_temp = j;
            String ttt = nButton_f[j].getText().toString();
            nButton_f[j].setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    //int resID = getResources().getIdentifier("Button" + i, "id", "com.example.memo");//    int resID = getResources().getIdentifier("com.androidside:id/Button"+i,null,null);
                    Intent intent = new Intent(getApplicationContext(), trash_folder.class);
                    String title = nButton_f[b_temp].getText().toString();
                    intent.putExtra("title", title);
                    intent.putExtra("btn_id",nButtonId_f[b_temp]);
                    startActivity(intent);
                    save();
                }
            });
        }
    }
    String temp;
    String temp_f;
    @Override
    public void onCreateContextMenu(ContextMenu menu, View v, ContextMenu.ContextMenuInfo menuInfo) {
        super.onCreateContextMenu(menu, v, menuInfo);
        for(int i = 0;i<count; i++){
            if(v==nButton[i]){
                temp = nButton[i].getText().toString();
                menu.add(0, 1, 0, "복원");
                menu.add(0, 2, 0, "삭제");
//                menu.add(0, 3, 0, "상단에 고정");
            }
        }
        for(int i = 0; i<count_f;i++){
            if(v==nButton_f[i]){
                temp_f = nButton_f[i].getText().toString();
                menu.add(0, 4, 0, "복원");
                menu.add(0, 5, 0, "삭제");
            }
        }
    }

    @Override
    public boolean onContextItemSelected(@NonNull MenuItem item) {
        for(int i = 0; i <count; i++) {
            if (temp == nButton[i].getText().toString()) {
                switch (item.getItemId()) {
                    case 1:
                        Rollback(i);
                        return true;
                    case 2:
                        count--;
                        int c = count+i;
                        nButton[i].setVisibility(View.GONE);
                        while(i<count){
                            int temp = i+1;
                            nButton[i] = nButton[temp];
//                            nButton[i].setId(temp);
                            value_save[i] = value_save[temp];
                            nButtonId[i] = nButton[i].getId();
                            /*if(count+i == c) {
                                delete(i);
                            }*/
                            i++;
                        }
                        count();
                        save();
                        return true;
                    /*case 3:
                        return true;*/
                }
            }
        }
        for(int i = 0; i <count_f; i++){
            if(temp_f == nButton_f[i].getText()){
                switch (item.getItemId()) {
                    case 4:
                        Rollback_f(i);

                        return true;
                    case 5:
                        count_f--;
                        int c = count_f+i;
                        if(count_f+i == c) {//-----------------폴더내 메모 삭제
                            int count_t = 0;
                            for(int j = 0; j < count; j++){
                                int btn_id = nButtonId[j]/100;
                                if(btn_id == nButtonId_f[i]) {
                                    nButton[j].setVisibility(View.GONE);
                                    count_t++;
                                    int t = j+1;
/*                                        nButton[j] = nButton[t];
//                            nButton[i].setId(temp);
                                        value_save[j] = value_save[t];
                                        nButtonId[j] = nButton[j].getId();*/
                                }
                            }
                            count = count-count_t;
                            delete(i);
                        }
                        nButton_f[i].setVisibility(View.GONE);
                        while(i<count_f){
                            int temp = i+1;
                            nButton_f[i] = nButton_f[temp];
//                            nButton[i].setId(temp);
                            value_save_f[i] = value_save_f[temp];
                            nButtonId_f[i] = nButton_f[i].getId();

                            i++;
                        }
                        count();
                        save();
                        return true;
                }
            }
        }

        return true;

        //return super.onContextItemSelected(item);
    }
    private void delete(int i){
        /*int temp = i+1;
        SharedPreferences folder_name = getSharedPreferences("folder_t"+temp, Context.MODE_PRIVATE);
        SharedPreferences.Editor edit = folder_name.edit();

        edit.putInt("count",0);

        edit.commit();*/
    }

    public void save(){
        Intent intent = getIntent();
        SharedPreferences trash = getSharedPreferences("trash", Context.MODE_PRIVATE);
        SharedPreferences.Editor edit = trash.edit();

        edit.putInt("trash_count_f",count_f);
        edit.putInt("trash_count",count);
        for (int i = 0; i < count; i++) {
            edit.putString("button_name"+i, value_save[i]);
           // edit.putInt("mbtn_id"+i,mbtn_id);//메모 아이디

//            edit.putInt("nButtonId"+i, nButtonId[i]);
        }
        for(int i = 0; i< count_f; i++){
            edit.putString("button_name_f"+i, value_save_f[i]);
        }
        edit.commit();
    }

    private void Rollback(int i){
        int count_m;
        String folder_n;
        int btn_id = nButtonId[i]/100;
        SharedPreferences folder_name = getSharedPreferences("folder"+btn_id, Context.MODE_PRIVATE);
        SharedPreferences.Editor edit = folder_name.edit();

        count_m = folder_name.getInt("count",-1);

        edit.putString("button_name"+(count_m-1),value_save[i]);

        folder_n = pref.getString("title","");
        edit.putString("title",folder_n);

        count_m++;
        edit.putInt("count",count_m);

        SharedPreferences memo = getSharedPreferences("memo"+nButtonId[i],Context.MODE_PRIVATE);
        SharedPreferences.Editor memo_edit = memo.edit();
        String content = memo.getString("content", "");
        memo_edit.putString("content", content);
        nButton[i].setVisibility(View.GONE);
        count--;

        edit.commit();
        count();
        save();
    }
    private void Rollback_f(int i){
        int count_m;
        SharedPreferences sharedPreferences = getSharedPreferences("Save", Context.MODE_PRIVATE);
        SharedPreferences.Editor edit = sharedPreferences.edit();

        count_m=sharedPreferences.getInt("count",-1);
        count_m++;

        edit.putString("button_name"+count_m,value_save_f[i]);
        edit.putInt("button_id"+count_m,nButtonId_f[i]);

        edit.putInt("count", count_m);
        edit.commit();
        SharedPreferences folder_name = getSharedPreferences("folder"+nButtonId_f[i], Context.MODE_PRIVATE);
        SharedPreferences.Editor edit1 = folder_name.edit();

        edit1.putInt("del",0);
        edit1.putInt("count",pref.getInt("save_count"+(i+1),0));
        nButton_f[i].setVisibility(View.GONE);
        count_f--;
        edit1.commit();

        count();
        save();

    }


    @Override
    public void onBackPressed() {
        super.onBackPressed();
        save();
        Intent intent = new Intent(getApplicationContext(),MainActivity.class);
        startActivity(intent);
        finish();
    }
}